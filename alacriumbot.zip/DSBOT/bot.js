const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers
    ]
});

// Генерация строки из 22 символов
function generateRandomString(length = 22) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';

    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    return result;
}

client.on('guildMemberAdd', async (member) => {
    const username = member.user.username;
    const password = generateRandomString(22);
    const trialKey = "FREE-3DAY-GH2M-L3LN";

    const embed = new EmbedBuilder()
        .setColor(0x5865F2) // Discord стиль фиолетовый
        .setTitle("🔐 Добро пожаловать в систему | Welcome to the System")
        .setThumbnail(member.user.displayAvatarURL())
        .setDescription(
`Ниже вы найдёте вашу автоматически созданную учётную запись.  
Below you will find your automatically generated account.`
        )
        .addFields(
            {
                name: "🇷🇺 **Информация (RU)**",
                value:
`Здравствуйте, **${username}** 👋  
Мы автоматически создали ваш приватный кабинет.

**Данные для входа:**  
• Логин: **${username}**  
• Пароль: **${password}**

Если вы новый пользователь, используйте ключ для получения **3 дней пробного периода**:

🔑 **${trialKey}**

📥 **Скачать лоадер можно в канале:**  
<#YOUR_CHANNEL_ID>  
(Укажи сюда ID канала с загрузкой)`,
                inline: false
            },
            {
                name: "🇬🇧 **Information (EN)**",
                value:
`Hello, **${username}** 👋  
We have automatically created your private account.

**Login details:**  
• Username: **${username}**  
• Password: **${password}**

If you are a new user, use this key to receive a **3-day free trial**:

🔑 **${trialKey}**

📥 **You can download the loader in the channel:**  
<#YOUR_CHANNEL_ID>`,
                inline: false
            }
        )
        .setFooter({ text: "Автоматическая система регистрации | Automated registration system" })
        .setTimestamp();

    member.send({ embeds: [embed] })
        .catch(() => console.log("Не удалось отправить сообщение пользователю."));
});

client.login('MTQ0NTgyODY3MzMxOTIwNzAzNQ.G-_rE4.i7eUcZbB_UpWuLajv_zhDQy8wLaiJEjagmKmYo');
